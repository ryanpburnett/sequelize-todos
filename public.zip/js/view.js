document.addEventListener('DOMContentLoaded', (e) => {
  console.log('DOM loaded!');

  // your code here...
});